<footer class="main-footer">
  <strong>Copyright &copy; <?php echo date('Y'); ?> </strong> All rights reserved.
</footer>