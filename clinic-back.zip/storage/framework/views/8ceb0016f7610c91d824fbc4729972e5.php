<section>
    <header>
        <h2 class="text-lg font-medium text-gray-900">
            <?php echo e(__('Profile Information')); ?>

        </h2>

        
    </header>

    <div class="col-md-12">
        <!--begin::Quick Example-->
        <div class="card card-primary card-outline mb-4">
            <!--begin::Header-->
            <div class="card-header">
                <div class="card-title"><?php echo e(__("Update your account's profile information and email address.")); ?></div>
            </div>
            <!--end::Header-->
            <!--begin::Form-->
            <form method="post" action="<?php echo e(route('profile.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <!--begin::Body-->
                <div class="card-body">
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input name="name" type="text" class="form-control" id="name"
                        value="<?php echo e(old('name', $user->name)); ?>" required >
                        <?php
                        $names = $errors->get('name');
                        ?>
                    <?php if($names): ?>
                        <ul style="color:red;">
                            <?php $__currentLoopData = (array) $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                        
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input  id="email" name="email" type="email"  class="form-control" value="<?php echo e(old('email', $user->email)); ?>" required >
                        <?php
                        $emails = $errors->get('email');
                        ?>
                    <?php if($emails): ?>
                        <ul style="color:red;">
                            <?php $__currentLoopData = (array) $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($email); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    </div>
                    

                </div>
                <!--end::Body-->
                <!--begin::Footer-->
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                <!--end::Footer-->
            </form>
            <!--end::Form-->
        </div>

    </div>

    

    
</section>
<?php /**PATH E:\clinic-back\resources\views/profile/partials/update-profile-information-form.blade.php ENDPATH**/ ?>