<?php $__env->startSection('content'); ?>
	<div class="login-box">
		<div class="login-logo">
			 <a href="<?php echo e(route('login')); ?>"><b>Charted</b>Accountant</a>
		</div>
		<div class="card">
			<div class="card-body login-card-body">
				<p class="login-box-msg">Sign in to start your session</p>
				<form method="post" action="<?php echo e(route('login')); ?>" id="loginForm">
					<?php echo csrf_field(); ?>
					<div class="input-group mb-3">
						<input type="email" class="form-control" placeholder="Email" name="email" required>
						<div class="input-group-text">
							<span class="fas fa-envelope"></span>
						</div>
						<?php if($errors->has('email')): ?>
							<div id="email-error" class="text-danger"><?php echo e($errors->first('email')); ?></div>
						<?php endif; ?>
					</div>
					<div class="input-group mb-3">
						<input type="password" class="form-control" placeholder="Password" name="password" required>
						<div class="input-group-text">
							<span class="fas fa-lock"></span>
						</div>
						<?php if($errors->has('password')): ?>
							<div id="password-error" class="text-danger"><?php echo e($errors->first('password')); ?></div>
						<?php endif; ?>
					</div>
					<div class="row">
						<div class="col-12">
							<div class="form-check">
								<input class="form-check-input" type="checkbox" name="remember" id="remember_me">
								<label class="form-check-label" for="flexCheckDefault">
									Remember Me
								</label>
							</div>
						</div>
						<div class="col-12 mt-4">
							<div class="d-grid gap-2">
								<button type="submit" class="btn btn-block btn-primary" id="submitButton">Sign In</button>
							  <!--button type="submit" class="btn btn-primary">Sign In</button-->
							</div>
						</div>
					</div>
				</form>
				<?php if(Route::has('password.request')): ?>
					<p class="mb-1 mt-4">
						<a href="<?php echo e(route('password.request')); ?>">I forgot my password</a>
					</p>
				<?php endif; ?>
				
			</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\clinic-back\resources\views/auth/login.blade.php ENDPATH**/ ?>