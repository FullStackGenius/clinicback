<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <main class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-4">
                    <div class="col-sm-6">
                        <h3 class="text-2xl font-semibold">Client Profile</h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Client Profile</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow-lg rounded-lg mb-5">
                            
                            <div class="card-header d-flex justify-content-between align-items-center bg-primary text-white">
                                <h3 class="card-title mb-0">Client Details</h3>
                                <a href="<?php echo e(route('client.index')); ?>" class="btn btn-dark btn-sm">Back To Clients</a>
                            </div>

                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>

                            <?php if(session('error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="card-body">
                                <table class="table table-hover">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="py-3 px-4">#</th>
                                            <th class="py-3 px-4">Information</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y">
                                        <tr>
                                            <th class="py-3 px-4 font-medium">Name</th>
                                            <td class="py-3 px-4"><?php echo e($client->name." ".$client->last_name); ?></td>
                                        </tr>
                                        <tr>
                                            <th class="py-3 px-4 font-medium">Email</th>
                                            <td class="py-3 px-4"><?php echo e($client->email); ?></td>
                                        </tr>
                                        <tr>
                                            <th class="py-3 px-4 font-medium">Type</th>
                                            <td class="py-3 px-4"><?php echo e(ucfirst(@$client->role->name )); ?></td>
                                        </tr>
                                        <tr>
                                            <th class="py-3 px-4 font-medium">Profile Image</th>
                                            <td class="py-3 px-4">
                                                <img class="rounded-lg shadow-sm" width="50px" height="54px" src="<?php echo e($client->profile_image_path); ?>">
                                            </td>
                                        </tr>
                                        <tr>
                                            <th class="py-3 px-4 font-medium">Status</th>
                                            <td class="py-3 px-4">
                                                <?php if($client->user_status == 1): ?>
                                                    <span class="badge bg-success changeYourStatus cursor-pointer" data-url="<?php echo e(route('change-status', $client->id)); ?>" title="Click to Inactive user"><i class="fa fa-check-circle"></i> Active</span>
                                                <?php endif; ?>
                                                <?php if($client->user_status == 0): ?>
                                                    <span class="badge bg-danger changeYourStatus cursor-pointer" data-url="<?php echo e(route('change-status', $client->id)); ?>" title="Click to active user"><i class="fa fa-times-circle"></i> Inactive</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th class="py-3 px-4 font-medium">Country</th>
                                            <td class="py-3 px-4"><?php echo e(@$client->country->name); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function () {
            $(document).on('click', '.changeYourStatus', function () {
                Swal.fire({
                    title: "Are you sure you want to change the status?",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Yes, change it!"
                }).then((result) => {
                    if (result.isConfirmed) {
                        let url = $(this).data('url');
                        window.location.href = url;
                    }
                });
            });

            setTimeout(function () {
                $('.alert').fadeOut('slow');
            }, 1000);
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\clinic-back\resources\views/client/show.blade.php ENDPATH**/ ?>