<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <main class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="fs-3">Jobs Details</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Project Details</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <!-- Project Details Card -->
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            
                            <div class="card-header d-flex justify-content-between align-items-center bg-primary text-white">
                                <h3 class="card-title mb-0"><b><?php echo e(ucfirst($jobDetails->title)); ?></b></h3>
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-dark btn-sm">Back to Jobs</a>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <strong>Description:</strong>
                                    <p><?php echo e($jobDetails->description); ?></p>
                                </div>
                                <div class="mb-3">
                                    <strong>Client Name:</strong>
                                    <p><?php echo e(ucfirst($jobDetails->clientUser->name) . ' ' . $jobDetails->clientUser->last_name); ?>

                                    </p>
                                </div>
                                <div class="mb-3">
                                    <strong>Created At:</strong>
                                    <p><?php echo e($jobDetails->created_at->format('d M, Y H:i')); ?></p>
                                </div>
                                <div class="mb-3">
                                    <strong>Budget Type:</strong>
                                    <p>
                                        <?php if($jobDetails->budget_type == 1): ?>
                                            <span class="badge bg-success">Hourly</span>
                                            </br>
                                            <?php echo e(!empty($jobDetails->hourly_from) ? "$" : ''); ?><?php echo e($jobDetails->hourly_from); ?>

                                            -
                                            <?php echo e(!empty($jobDetails->hourly_to) ? "$" : ''); ?><?php echo e($jobDetails->hourly_to); ?>

                                        <?php elseif($jobDetails->budget_type == 2): ?>
                                            <span class="badge bg-success">Fixed</span>
                                            </br>
                                            <?php echo e(!empty($jobDetails->fixed_rate) ? "$" : ''); ?><?php echo e($jobDetails->fixed_rate); ?>

                                        <?php endif; ?>


                                    </p>
                                </div>
                                <div class="mb-3">
                                    <strong>Status:</strong>
                                    <p>
                                        <?php if($jobDetails->project_status == 1): ?>
                                            <span class="badge bg-success">pending</span>
                                        <?php endif; ?>
                                        <?php if($jobDetails->project_status == 2): ?>
                                            <span class="badge bg-success">draft</span>
                                        <?php endif; ?>
                                        <?php if($jobDetails->project_status == 3): ?>
                                            <span class="badge bg-success">publish</span>
                                        <?php endif; ?>
                                        <?php if($jobDetails->project_status == 4): ?>
                                            <span class="badge bg-success">closed</span>
                                        <?php endif; ?>
                                    </p>
                                </div>

                                <div class="mb-3">
                                    <strong>Project skills:</strong>
                                    <p>
                                        <?php
                                            $projectSkills = $jobDetails->projectSkill;
                                            $skills = $projectSkills->pluck('name')->implode(' , ');
                                        ?>

                                        <?php echo e(!empty($skills) ? $skills : 'not defined'); ?>

                                    </p>
                                </div>

                                <div class="mb-3">
                                    <strong>Project Category:</strong>
                                    <p>
                                        <?php
                                            $projectCategory = $jobDetails->projectCategory;
                                            $projectsector = $projectCategory->pluck('name')->implode(' , ');
                                        ?>
                                        <?php echo e(!empty($projectsector) ? $projectsector : 'not defined'); ?>

                                    </p>
                                </div>

                                <div class="mb-3">
                                    <strong>Project Subcategory:</strong>
                                    <p>
                                        <?php
                                            $projectSubCategory = $jobDetails->projectSubCategory;
                                            $projectSubCategoryData = $projectSubCategory
                                                ->pluck('name')
                                                ->implode(' , ');
                                        ?>

                                        <?php echo e(!empty($projectSubCategoryData) ? $projectSubCategoryData : 'not defined'); ?>

                                    </p>
                                </div>

                                <?php if($jobDetails->contracts): ?>
                                <div class="mb-3">
                                    <strong>Assigned Freelancer:</strong>
                                    <p>
                                        <?php if($jobDetails?->contracts?->proposal?->freelancerUser): ?>
                                        <a href="<?php echo e(route('freelancer.show',$jobDetails->contracts->proposal->freelancerUser->id)); ?>"><?php echo e($jobDetails->contracts->proposal->freelancerUser->name); ?> <?php echo e($jobDetails->contracts->proposal->freelancerUser->last_name); ?></a>
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <?php endif; ?>

                                


                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
    </main>
    <!-- /.content-wrapper -->
    <!--- assign model ---->
    <!-- The Modal -->
    
   
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        setTimeout(function() {
            $('.alert').fadeOut('slow');
        }, 2000);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\clinic-back\resources\views/jobs/show.blade.php ENDPATH**/ ?>