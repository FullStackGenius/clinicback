<section>
    <header>
        <h2 class="text-lg font-medium text-gray-900">
            <?php echo e(__('Update Password')); ?>

        </h2>

        
    </header>

    <div class="col-md-12">
        <!--begin::Quick Example-->
        <div class="card card-primary card-outline mb-4">
            <!--begin::Header-->
            <div class="card-header">
                <div class="card-title"><?php echo e(__('Ensure your account is using a long, random password to stay secure.')); ?></div>
            </div>
            <!--end::Header-->
            <!--begin::Form-->
            <form method="post" action="<?php echo e(route('password.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <!--begin::Body-->
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label"
                            for="update_password_current_password"><?php echo e(__('Current Password')); ?></label>
                        <input id="update_password_current_password" name="current_password" type="password"
                            autocomplete="current-password" class="form-control">
                            <?php
                            $messages = $errors->updatePassword->get('current_password');
                            ?>
                        <?php if($messages): ?>
                            <ul style="color:red;">
                                <?php $__currentLoopData = (array) $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>

                    </div>
                    <div class="mb-3">
                        <label for="update_password_password" class="form-label"><?php echo e(__('New Password')); ?></label>
                        <input id="update_password_password" name="password" type="password" autocomplete="new-password"
                            class="form-control">
                            <?php
                            $messages_password = $errors->updatePassword->get('password');
                            ?>
                        <?php if($messages_password): ?>
                            <ul style="color:red;">
                                <?php $__currentLoopData = (array) $messages_password; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message_password): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message_password); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="update_password_password_confirmation"
                            class="form-label"><?php echo e(__('Confirm Password')); ?></label>
                        <input id="update_password_password_confirmation" name="password_confirmation" type="password"
                            autocomplete="new-password" class="form-control">
                            <?php
                            $passwords_confirmation = $errors->updatePassword->get('password_confirmation');
                            ?>
                        <?php if($passwords_confirmation): ?>
                            <ul>
                                <?php $__currentLoopData = (array) $passwords_confirmation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $password_confirmation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($password_confirmation); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                    

                </div>
                <!--end::Body-->
                <!--begin::Footer-->
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                <!--end::Footer-->
            </form>
            <!--end::Form-->
        </div>

    </div>

    
</section>
<?php /**PATH E:\clinic-back\resources\views/profile/partials/update-password-form.blade.php ENDPATH**/ ?>