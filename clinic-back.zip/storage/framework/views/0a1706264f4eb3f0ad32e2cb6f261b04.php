 <!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-light">
  <div class="container-fluid">
    <!-- Start navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-lte-toggle="sidebar-full" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      
    </ul>

    <!-- End navbar links -->
    <ul class="navbar-nav ms-auto">
      <!-- Navbar Search -->
      

      <!-- Messages Dropdown Menu -->
      
      <!-- Notifications Dropdown Menu -->
      
      <li class="nav-item dropdown user-menu">
        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
          <img src="<?php echo e(Auth::user()->profile_image_path); ?>" class="user-image img-circle shadow" alt="User Image">
          
          <span class="d-none d-md-inline"><?php echo e(ucfirst(Auth::user()->name)); ?></span>
        </a>
        <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
          <!-- User image -->
          <li class="user-header bg-primary">
            <img src="<?php echo e(Auth::user()->profile_image_path); ?>" class="img-circle shadow" alt="User Image">

            <p>
              <?php echo e(ucfirst(Auth::user()->name)); ?>

              
            </p>
          </li>
          <!-- Menu Body -->
          
          <!-- Menu Footer-->
          <li class="user-footer">
            <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-default btn-flat">Profile</a>
            
            <form method="POST" action="<?php echo e(route('logout')); ?>" class=" float-end">
              <?php echo csrf_field(); ?>
              <a class="btn btn-default btn-flat" href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault();
                                  this.closest('form').submit();"><?php echo e(__('Sign Out')); ?></a>
          </form>
          </li>
        </ul>
      </li>
      <!-- TODO tackel in v4.1 -->
      <!-- <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
          <i class="fas fa-th-large"></i>
        </a>
      </li> -->
    </ul>
  </div>
</nav>
<!-- /.navbar --><?php /**PATH E:\clinic-back\resources\views/layouts/admin-partials/header.blade.php ENDPATH**/ ?>