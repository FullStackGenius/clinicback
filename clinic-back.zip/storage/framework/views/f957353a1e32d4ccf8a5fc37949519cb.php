<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <main class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h2 class="fs-3 text-dark">Client Jobs</h2>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Client Jobs</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <!-- Info boxes -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4 shadow-sm">
                            <div  class="card-header d-flex justify-content-between align-items-center bg-primary text-white">
                                <h3 class="card-title">Client Jobs</h3>
                            </div>

                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>

                            <?php if(session('error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>

                            <!-- /.card-header -->
                            <div class="card-body p-3">
                                <table class="table table-striped table-hover">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>#</th>
                                            <th>Job Title</th>
                                            <th>Description</th>
                                            <th>Status</th>
                                            <th>Posted By</th>
                                            <th>Posted On</th>
                                            <th>Freelancer Proposal</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr class="align-middle">
                                                <td>
                                                    <?php
                                                        $perPage = $jobs->perPage(); 
                                                        $currentPage = $jobs->currentPage(); 
                                                        $startingSerno = ($currentPage - 1) * $perPage; 
                                                    ?>
                                                    <?php echo e($startingSerno + $loop->iteration); ?>

                                                </td>
                                                <td><?php echo e(@$job->title); ?></td>
                                                <td>
                                                    <div class="description-container">
                                                        <span class="short-description"><?php echo e(Str::limit(@$job->description, 60)); ?></span>
                                                        <span class="full-description" style="display:none;"><?php echo e(@$job->description); ?></span>
                                                        <?php if(strlen(@$job->description) > 60): ?>
                                                            <a href="javascript:void(0)" class="read-more-btn">Read More</a>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php switch(@$job->project_status):
                                                        case (1): ?>
                                                            <span class="badge bg-success"><?php echo e(@$job->project_status_label); ?></span>
                                                            <?php break; ?>
                                                        <?php case (2): ?>
                                                            <span class="badge bg-primary"><?php echo e(@$job->project_status_label); ?></span>
                                                            <?php break; ?>
                                                        <?php case (3): ?>
                                                        <span class="badge bg-primary"><?php echo e(@$job->project_status_label); ?></span>
                                                        <?php break; ?>
                                                        <?php case (4): ?>
                                                            <span class="badge bg-warning"><?php echo e(@$job->project_status_label); ?></span>
                                                            <?php break; ?>
                                                    <?php endswitch; ?>
                                                </td>
                                                <td><a href="<?php echo e(route('client.show', encodeId(@$job->clientUser->id))); ?>"><?php echo e(ucfirst(@$job->clientUser->name)); ?> <?php echo e(@$job->clientUser->last_name); ?></a></td>
                                                <td><p title="<?php echo e(@$job->created_at); ?>"><?php echo e(@$job->created_at->diffForHumans()); ?></p></td>
                                                <td><a href="<?php echo e(route('job-proposal', @$job->id)); ?>" class="btn btn-primary btn-sm mb-2">View Proposal</a></td>
                                                <td style="display: flex;column-gap: 5px;">
                                                    <a href="<?php echo e(route('jobs.show', @$job->id)); ?>" class="btn btn-primary btn-sm">
                                                        <i class="fas fa-eye"></i>
                                                        Details</a>
                                                </td>
                                            </tr>
                                       

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="9" class="text-center">No jobs available</td>
                                        </tr>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer clearfix">
                                <?php echo $jobs->links('pagination::bootstrap-4'); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.read-more-btn').on('click', function() {
                var $this = $(this);
                var $descriptionContainer = $this.closest('.description-container');
                
                // Toggle visibility of descriptions
                $descriptionContainer.find('.short-description').toggle();
                $descriptionContainer.find('.full-description').toggle();
                
                // Change button text
                if ($descriptionContainer.find('.full-description').is(':visible')) {
                    $this.text('Read Less');
                } else {
                    $this.text('Read More');
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\clinic-back\resources\views/jobs/index.blade.php ENDPATH**/ ?>