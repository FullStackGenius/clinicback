<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <main class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <div class="fs-3">Languages</div>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Skill</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <!-- Info boxes -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-12">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h3 class="card-title">Languages </h3> <a href="<?php echo e(route('language.create')); ?>"
                                    class="btn btn-primary btn-sm "><i class="fa fa-plus-circle"></i> Languages</a>
                            </div>
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>

                            <?php if(session('error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th style="width: 10px"><i class="fa fa-list-ol"></i></th>
                                            <th>Language</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="align-middle">
                                                <td>

                                                    <?php
                                                        $perPage = $languages->perPage(); // Number of items per page
                                                        $currentPage = $languages->currentPage(); // Current page number
                                                        $startingSerno = ($currentPage - 1) * $perPage; // Calculate starting serial number
                                                    ?>
                                                    <?php echo e($startingSerno + $loop->iteration); ?>

                                                </td>

                                                <td>
                                                    <?php echo e($language->name); ?>

                                                </td>
                                                <td>
                                                    <?php if(@$language->status == 1): ?>
                                                        <span class="badge bg-success"><i class="fa fa-check-circle"></i> Active</span>
                                                    <?php endif; ?>
                                                    <?php if(@$language->status == 0): ?>
                                                        <span class="badge bg-danger"><i class="fa fa-times-circle"></i> Inactive</span>
                                                    <?php endif; ?>


                                                </td>
                                                <td style="display: flex;column-gap: 5px;"><a
                                                        href="<?php echo e(route('language.edit', $language->id)); ?>"
                                                        class="btn btn-primary btn-sm mb-2"><i class="fa fa-edit"></i> Edit</a>
                                                    <form action="<?php echo e(route('language.destroy', $language->id)); ?>" method="POST"
                                                        id="submitDeleteForm<?php echo e($language->id); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button data-token="<?php echo e($language->id); ?>"
                                                            class="btn btn-danger btn-sm mb-2 confirmDelete"
                                                            type="button"><i class="fa fa-trash"></i> Delete</button>
                                                    </form>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer clearfix">
                                <?php echo $languages->links('pagination::bootstrap-4'); ?>

                                
                            </div>
                        </div>

                    </div>

                </div>
                <!-- /.row -->


                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
    </main>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            setTimeout(function() {
                $('.alert').fadeOut('slow');
            }, 1000);

            $(document).on('click', '.confirmDelete', function() {
                let token = $(this).data('token');
                Swal.fire({
                    title: "Are you sure?",
                    text: "You won't be able to revert this!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Yes, delete it!"
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#submitDeleteForm' + token).submit();
                    }
                });
            })

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\clinic-back\resources\views/languages/index.blade.php ENDPATH**/ ?>