<section>
    <header>
        <h2 class="text-lg font-medium text-gray-900">
            <?php echo e(__('Profile Image')); ?>

        </h2>

        
    </header>

    <div class="col-md-12">
        <!--begin::Quick Example-->
        <div class="card card-primary card-outline mb-4">
            <!--begin::Header-->
            <div class="card-header">
                <div class="card-title"><?php echo e(__('Ensure your account is using a long, random password to stay secure.')); ?></div>
            </div>
            <!--end::Header-->
            <!--begin::Form-->
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

            <form method="post" action="<?php echo e(route('update-profile-image')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
              
                <!--begin::Body-->
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label"
                            for="profile_image"><?php echo e(__('Profile Image')); ?></label>
                        <input id="profile_image" name="profile_image" type="file"
                             class="form-control" required>
                            <?php
                            $messages = $errors->updatePassword->get('profile_image');
                            ?>
                        <?php if($messages): ?>
                            <ul style="color:red;">
                                <?php $__currentLoopData = (array) $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>

                    </div>
                 

                 
                    

                </div>
                <!--end::Body-->
                <!--begin::Footer-->
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                <!--end::Footer-->
            </form>
            <!--end::Form-->
        </div>

    </div>

    
</section>
<?php /**PATH E:\clinic-back\resources\views/profile/partials/update-profile-image.blade.php ENDPATH**/ ?>