<?php $__env->startSection('content'); ?>
	 <!-- Main content -->
      <main class="content-wrapper">
        <div class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <div class="fs-3">Dashboard</div>
              </div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
        <div class="content">
          <div class="container-fluid">
            <!-- Info boxes -->
            <div class="row">
              
              <!-- /.col -->
              
              <!-- /.col -->

              <!-- fix for small devices only -->
              <!-- <div class="clearfix hidden-md-up"></div> -->

              
              <!-- /.col -->
              <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                  <span class="info-box-icon bg-warning shadow-sm"><i class="fas fa-users"></i></span>

                  <div class="info-box-content" onclick="window.location.href='<?php echo e(route('freelancer.index')); ?>';" style="cursor: pointer;">
                    <span class="info-box-text">Freelancer</span>
                    <span class="info-box-number"><?php echo e(@$freelancer); ?></span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </div>
              <!-- /.col -->
              <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box" onclick="window.location.href='<?php echo e(route('client.index')); ?>';" style="cursor: pointer;">
                  <span class="info-box-icon bg-success shadow-sm"><i class="fas fa-users"></i></span>

                  <div class="info-box-content">
                    <span class="info-box-text">Clinet</span>
                    <span class="info-box-number"><?php echo e(@$client); ?></span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </div>

              <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box" onclick="window.location.href='<?php echo e(route('jobs.index')); ?>';" style="cursor: pointer;">
                  <span class="info-box-icon bg-primary shadow-sm"><i class="fas fa-briefcase"></i></span>

                  <div class="info-box-content">
                    <span class="info-box-text">Jobs</span>
                    <span class="info-box-number"><?php echo e(@$jobs); ?></span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </div>
            </div>
            <!-- /.row -->

            
            <!-- /.row -->

            <!-- Main row -->
            
            <!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>
      </main>
      <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <!-- ChartJS -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.6.0/dist/chart.min.js" integrity="sha256-7lWo7cjrrponRJcS6bc8isfsPDwSKoaYfGIHgSheQkk=" crossorigin="anonymous"></script>

    <script>
      // NOTICE!! DO NOT USE ANY OF THIS JAVASCRIPT
      // IT'S ALL JUST JUNK FOR DEMO
      // ++++++++++++++++++++++++++++++++++++++++++

      /* ChartJS
        * -------
        * Here we will create a few charts using ChartJS
        */

      //-----------------------
      // - MONTHLY SALES CHART -
      //-----------------------
      (function () {
        'use strict'
        // Get context with querySelector - using Chart.js .getContext('2d') method.
        var salesChartCanvas = document.querySelector('#salesChart').getContext('2d')

        var salesChartData = {
          labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
          datasets: [
            {
              label: 'Digital Goods',
              backgroundColor: 'rgba(60,141,188,0.9)',
              borderColor: 'rgba(60,141,188,0.8)',
              fill: true,
              pointRadius: 0,
              pointColor: '#3b8bba',
              pointStrokeColor: 'rgba(60,141,188,1)',
              pointHighlightFill: '#fff',
              pointHighlightStroke: 'rgba(60,141,188,1)',
              data: [28, 48, 40, 19, 86, 27, 90]
            },
            {
              label: 'Electronics',
              backgroundColor: 'rgba(210, 214, 222, 1)',
              borderColor: 'rgba(210, 214, 222, 1)',
              fill: true,
              pointRadius: 0,
              pointColor: 'rgba(210, 214, 222, 1)',
              pointStrokeColor: '#c1c7d1',
              pointHighlightFill: '#fff',
              pointHighlightStroke: 'rgba(220,220,220,1)',
              data: [65, 59, 80, 81, 56, 55, 40]
            }
          ]
        }

        var salesChartOptions = {
          maintainAspectRatio: false,
          responsive: true,
          tension: 0.4,
          plugins: {
            legend: {
              display: false
            }
          },
          scales: {
            xAxes: {
              gridLines: {
                display: false
              }
            },
            yAxes: {
              gridLines: {
                display: false
              }
            }
          }
        }

        // This will get the first returned node in the js collection.
        var salesChart = new Chart(salesChartCanvas, {
          type: 'line',
          data: salesChartData,
          options: salesChartOptions
        })

        //---------------------------
        // - END MONTHLY SALES CHART -
        //---------------------------

        //-------------
        // - PIE CHART -
        //-------------

        // Get context with querySelector - using Chart.js .getContext('2d') method.
        var pieChartCanvas = document.querySelector('#pieChart').getContext('2d')

        var pieData = {
          labels: [
            'Chrome',
            'IE',
            'FireFox',
            'Safari',
            'Opera',
            'Navigator'
          ],
          datasets: [
            {
              data: [700, 500, 400, 600, 300, 100],
              backgroundColor: ['#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc', '#d2d6de']
            }
          ]
        }
        var pieOptions = {
          plugins: {
            legend: {
              display: false
            }
          }
        }
        // Create pie or douhnut chart
        // You can switch between pie and douhnut using the method below.
        // eslint-disable-next-line no-unused-vars
        var pieChart = new Chart(pieChartCanvas, {
          type: 'doughnut',
          data: pieData,
          options: pieOptions
        })
      })()
      //-----------------
      // - END PIE CHART -
      //-----------------
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\clinic-back\resources\views/dashboard.blade.php ENDPATH**/ ?>